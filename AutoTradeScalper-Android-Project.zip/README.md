# AutoTrade Scalper — Android

Primera versión instalable en modo DEMO. Simula operaciones cortas y NO envía órdenes reales.

## Cómo obtener el APK sin instalar Android Studio

1. Crear un repositorio en GitHub.
2. Subir todos los archivos de este proyecto.
3. Entrar a **Actions**.
4. Ejecutar **Build Android APK**.
5. Cuando termine, abrir la ejecución y descargar el artefacto **AutoTradeScalper-debug**.
6. Dentro estará `app-debug.apk`.

GitHub Actions compila el proyecto en la nube. Para producción hay que firmar el APK con una clave privada propia.

## Próxima fase: dinero real

No colocar API keys dentro de la app. La arquitectura recomendada es:

Android app -> backend seguro -> broker/exchange

Conectores previstos:
- Binance Spot API para cripto.
- IOL API para acciones/CEDEARs argentinos.
- OANDA v20 para Forex.

Antes de producción: backtest, paper trading, comisiones/spread/slippage, límites de pérdida y pruebas de seguridad.
