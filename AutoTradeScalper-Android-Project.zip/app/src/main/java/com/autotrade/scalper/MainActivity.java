package com.autotrade.scalper;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    LinearLayout root, log;
    TextView status, balance, pnl, mode;
    boolean running = false;
    double simulatedBalance = 1000.00;
    Handler handler = new Handler(Looper.getMainLooper());
    Runnable tick;

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    TextView tv(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setPadding(dp(12), dp(8), dp(12), dp(8));
        return t;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        build();
    }

    void build() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(16));
        root.setBackgroundColor(Color.rgb(11,16,32));

        TextView title = tv("AutoTrade Scalper", 26, Color.WHITE, true);
        root.addView(title);
        root.addView(tv("Operaciones cortas • DEMO", 14, Color.LTGRAY, false));

        LinearLayout cards = new LinearLayout(this);
        cards.setOrientation(LinearLayout.HORIZONTAL);
        balance = tv("Saldo\n$1,000.00", 16, Color.WHITE, true);
        pnl = tv("P/L\n$0.00", 16, Color.WHITE, true);
        cards.addView(balance, new LinearLayout.LayoutParams(0, dp(80), 1));
        cards.addView(pnl, new LinearLayout.LayoutParams(0, dp(80), 1));
        root.addView(cards);

        mode = tv("MODO DEMO — no se envían órdenes reales", 14, Color.YELLOW, true);
        root.addView(mode);

        status = tv("Bot detenido", 18, Color.WHITE, true);
        root.addView(status);

        Button start = new Button(this);
        start.setText("INICIAR SCALPER DEMO");
        start.setOnClickListener(v -> toggle(start));
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("DETENER");
        stop.setOnClickListener(v -> stopBot());
        root.addView(stop);

        root.addView(tv("Mercados", 18, Color.WHITE, true));
        root.addView(tv("BTC/USDT    •    ETH/USDT    •    EUR/USD", 15, Color.LTGRAY, false));

        root.addView(tv("Operaciones", 18, Color.WHITE, true));
        log = new LinearLayout(this);
        log.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this);
        sv.addView(log);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);
    }

    void toggle(Button b) {
        if (running) return;
        running = true;
        status.setText("🟢 Bot ejecutando en DEMO");
        tick = new Runnable() {
            int n = 0;
            public void run() {
                if (!running) return;
                n++;
                double change = ((n % 5 == 0) ? -0.35 : 0.42);
                simulatedBalance += change;
                double p = simulatedBalance - 1000;
                balance.setText(String.format(Locale.US, "Saldo\n$%,.2f", simulatedBalance));
                pnl.setText(String.format(Locale.US, "P/L\n%+.2f", p));
                TextView row = tv((n % 2 == 0 ? "BUY " : "SELL ") + "  BTC/USDT   " +
                        String.format(Locale.US, "%+.2f", change) + "   •   DEMO", 14, Color.WHITE, false);
                log.addView(row, 0);
                if (log.getChildCount() > 30) log.removeViewAt(log.getChildCount()-1);
                handler.postDelayed(this, 1800);
            }
        };
        handler.post(tick);
    }

    void stopBot() {
        running = false;
        if (tick != null) handler.removeCallbacks(tick);
        status.setText("Bot detenido");
    }

    @Override protected void onDestroy() {
        stopBot();
        super.onDestroy();
    }
}
